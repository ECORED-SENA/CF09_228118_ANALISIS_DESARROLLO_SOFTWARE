function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6TUHnjHT9Q2":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

